﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using WhereTrainBuild.MapUtil.Data;

namespace WhereTrainBuild.Script
{
    /// <summary>
    /// サンプル構築
    /// </summary>
    public class TransitBuildLogic
    {
        /// <summary>
        /// コンストラクタ
        /// </summary>
        public TransitBuildLogic()
        {
        }

        /// <summary>
        /// 構築
        /// </summary>
        /// <param name="factory">対象ファクトリ</param>
        /// <param name="basefolder">ベースフォルダ</param>
        /// <param name="cnt">コントロール</param>
        /// <returns>戻値</returns>
        public object Build(BaseFactory factory, string basefolder, Control cnt)
        {
            //駅A
            var stationa = new StationInfoData();
            stationa.Name = "駅A";
            stationa.Latitude = 34.687202;
            stationa.Longitude = 135.525694;
            stationa.UniqID = factory.GetStationManager().NextUniqID();
            factory.GetStationManager().Add(stationa);

            //駅B
            var stationb = new StationInfoData();
            stationb.Name = "駅B";
            stationb.Latitude = 34.687298;
            stationb.Longitude = 135.511650;
            stationb.UniqID = factory.GetStationManager().NextUniqID();
            factory.GetStationManager().Add(stationb);

            //駅C
            var stationc = new StationInfoData();
            stationc.Name = "駅C";
            stationc.Latitude = 34.680037;
            stationc.Longitude = 135.512934;
            stationc.UniqID = factory.GetStationManager().NextUniqID();
            factory.GetStationManager().Add(stationc);

            //経路
            var path1 = new TrainPath();
            path1.Order = 1;
            path1.UniqID = factory.GetNetwork().NextPathUniqID();
            path1.StationA = stationa;
            path1.StationB = stationb;
            factory.GetNetwork().AddPath(path1);

            var path2 = new TrainPath();
            path2.Order = 2;
            path2.UniqID = factory.GetNetwork().NextPathUniqID();
            path2.StationA = stationb;
            path2.StationB = stationc;
            factory.GetNetwork().AddPath(path2);

            //方面構築
            var kindlist = new string[] { "平日", "土日祝日" };

            foreach (var kind in kindlist)
            {
                var line = new TrainLine();
                line.Name = "名前";
                line.Display = "表示名";
                foreach (var path in factory.GetNetwork().BuildLine(factory.GetStationManager().Get("駅A"), factory.GetStationManager().Get("駅C"))[0])
                {
                    line.AddPath(path.Clone() as TrainPath);
                }
                factory.GetNetwork().AddLine(kind, line);

                //電車構築
                for (int iHour = 4; iHour <= 23; iHour++)
                {
                    var train = new TrainInfo();
                    train.Name = iHour.ToString();
                    train.Display = "1方面";
                    train.StartStation = "A";
                    train.EndStation = "C";
                    train.Kind = "普通";
                    line.AddTrain(train);

                    var plan = new SceduleManager.Plan();
                    plan.Order = 1;
                    plan.AliveTime = new TimeSpan(iHour, 0, 0);
                    plan.StartTime = new TimeSpan(iHour, 1, 0);
                    plan.Station = factory.GetStationManager().Get("駅A");
                    train.Scedule.Add(plan);
                    plan = new SceduleManager.Plan();
                    plan.Order = 2;
                    plan.AliveTime = new TimeSpan(iHour, 20, 0);
                    plan.StartTime = new TimeSpan(iHour, 21, 0);
                    plan.Station = factory.GetStationManager().Get("駅B");
                    train.Scedule.Add(plan);
                    plan = new SceduleManager.Plan();
                    plan.Order = 3;
                    plan.AliveTime = new TimeSpan(iHour, 58, 0);
                    plan.StartTime = new TimeSpan(iHour, 59, 0);
                    plan.Station = factory.GetStationManager().Get("駅C");
                    train.Scedule.Add(plan);
                }
            }

            return "OK";
        }
    }
}
